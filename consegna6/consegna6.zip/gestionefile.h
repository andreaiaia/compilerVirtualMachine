#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void rename_file(char[], char[]);
void write(char[], FILE *);